interface Produto {

    nome: string;
    preco: number;
    tipo: 'eletrônico' | 'vestuário' | 'alimento'

}

function criarProduto(nome: string, preco: number, tipo: 'eletrônico' | 'vestuário' | 'alimento' ):
    Produto{
        return {nome, preco, tipo};
    }


// criando produtos   
const pc: Produto = criarProduto('pc', 5000, 'eletrônico');
const tenis: Produto = criarProduto('tenis', 500, 'vestuário');
const cafe: Produto = criarProduto('cafe', 10, 'alimento');

console.log(pc)
console.log(tenis)
console.log(cafe)