// Exercício 1 - Interfaces e Tipos Avançados

// Definição da interface Usuario
interface Usuario {
    nome: string;
    idade: number;
    tipo: 'administrador' | 'funcionario' | 'cliente';
}

// Função para criar um usuário com base no tipo
function criarUsuario(nome: string, idade: number, tipo: 'administrador' | 'funcionario' | 'cliente'): Usuario {
    return { nome, idade, tipo };
}

// Criando usuários
const admin = criarUsuario('Admin', 30, 'administrador');
const funcionario = criarUsuario('Funcionario', 25, 'funcionario');
const cliente = criarUsuario('Cliente', 40, 'cliente');

// Imprimindo informações dos usuários
console.log(admin);
console.log(funcionario);
console.log(cliente);