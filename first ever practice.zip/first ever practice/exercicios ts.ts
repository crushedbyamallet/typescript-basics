// back to basics

//ex 1

let cidade: string = 'coitadolandia';

console.log(cidade)

//ex 2

interface Carro {
    marca: string;
    ano: number;
}
let meuCarro: Carro = { marca: "leroleros", ano: 2021 };

console.log(meuCarro)

//ex 3

interface animal {
    emitirSom(): string;

}

let cachorro: animal = {
    emitirSom() {
        return 'jeep'
    },
}

//ex 4

type VerificarIdade = (idade: number) => boolean;
const verificarMaioridade21: VerificarIdade = (idade) => idade > 21;

const isMaiorDe21 = verificarMaioridade21(22);

console.log(isMaiorDe21); 



//ex 5

function saudacao (nome: string, sobrenome?: string): string {
    if (sobrenome) {
        return 'oi &{nome} &{sobrenome}';
    } else{
        return 'oi ${nome}'
    }
}

console.log(saudacao)
